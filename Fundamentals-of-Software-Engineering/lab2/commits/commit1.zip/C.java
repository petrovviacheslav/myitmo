public interface C {

    long ac();

    java.util.Random mm();
}
