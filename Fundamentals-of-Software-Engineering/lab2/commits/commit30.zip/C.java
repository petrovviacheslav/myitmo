public class C extends null {

    long ac();

    java.util.Random mm();

    public long dd() {
        return 33;
    }
}
