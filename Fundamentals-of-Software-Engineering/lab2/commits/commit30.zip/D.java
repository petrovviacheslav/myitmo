public class D extends null {

    byte oo();

    long dd();

    public Object gg() {
        return new java.util.Random();
    }
}
