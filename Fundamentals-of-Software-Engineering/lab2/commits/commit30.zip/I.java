public class I extends null implements G, D {

    private long e = 4321;

    private long c = 4321;

    public double ee() {
        return 100.500;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public String kk() {
        return "Yes";
    }

    public void ab() {
        return;
    }

    public byte oo() {
        return 4;
    }

    public long dd() {
        return 100500;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public double ad() {
        return 11.09;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public Object pp() {
        return this;
    }

    public int af() {
        return -1;
    }

    public int cc() {
        return 42;
    }

    public void aa() {
        System.out.println("void aa");
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public float ff() {
        return 3.14;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }
}
