public class G extends null {

    String kk();

    void ab();

    public Object gg() {
        return return getClass().getClassLoader();
    }
}
