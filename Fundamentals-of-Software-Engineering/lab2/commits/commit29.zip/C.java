public class C extends null {

    long ac();

    java.util.Random mm();

    public void ab() {
        System.out.println();
    }
}
