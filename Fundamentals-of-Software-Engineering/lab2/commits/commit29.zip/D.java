public class D extends null {

    byte oo();

    long dd();

    public java.lang.Class qq() {
        return getClass();
    }
}
