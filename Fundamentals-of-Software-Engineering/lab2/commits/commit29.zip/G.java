public class G extends null {

    String kk();

    void ab();

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
