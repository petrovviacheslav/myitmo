public class I extends null implements G, D {

    private long e = 4321;

    private long c = 4321;

    public double ee() {
        return 100.500;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public String kk() {
        return "Yes";
    }

    public void ab() {
        return;
    }

    public byte oo() {
        return 4;
    }

    public long dd() {
        return 100500;
    }

    public double ad() {
        return 11.09;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public Object pp() {
        return this;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public int cc() {
        return 42;
    }

    public void aa() {
        return;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public Object rr() {
        return null;
    }

    public int af() {
        return -1;
    }
}
