public class G extends null {

    String kk();

    void ab();

    public int af() {
        return -1;
    }
}
