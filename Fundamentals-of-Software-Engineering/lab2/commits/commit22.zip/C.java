public class C extends null {

    long ac();

    java.util.Random mm();

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }
}
