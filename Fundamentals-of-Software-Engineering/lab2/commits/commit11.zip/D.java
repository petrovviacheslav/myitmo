public interface D {

    byte oo();

    long dd();
}
