public class C extends null {

    long ac();

    java.util.Random mm();

    public double ee() {
        return 500.100;
    }
}
