public class G extends null {

    String kk();

    void ab();

    public Object gg() {
        return new java.util.Random();
    }
}
