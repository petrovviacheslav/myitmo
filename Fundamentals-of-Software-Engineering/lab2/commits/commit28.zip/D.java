public class D extends null {

    byte oo();

    long dd();

    public int cc() {
        return 42;
    }
}
