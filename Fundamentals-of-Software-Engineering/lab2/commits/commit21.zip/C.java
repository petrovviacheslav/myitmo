public class C extends null {

    long ac();

    java.util.Random mm();
}
