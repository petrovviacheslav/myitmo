public class G extends null {

    String kk();

    void ab();
}
