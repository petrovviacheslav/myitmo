public class D extends null {

    byte oo();

    long dd();

    public double ee() {
        return 100.500;
    }
}
