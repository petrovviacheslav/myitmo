public class I extends null implements G, D {

    private long e = 4321;

    private long c = 4321;

    public double ee() {
        return 100.500;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public String kk() {
        return "Yes";
    }

    public void ab() {
        return;
    }

    public byte oo() {
        return 4;
    }

    public long dd() {
        return 100500;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ad() {
        return 11.09;
    }

    public float ff() {
        return 3.14;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public int cc() {
        return 39;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }
}
