public class I extends null implements G, D {

    private long e = 4321;

    private long c = 4321;

    public double ee() {
        return 100.500;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public String kk() {
        return "Yes";
    }

    public void ab() {
        return;
    }

    public byte oo() {
        return 4;
    }

    public long dd() {
        return 100500;
    }

    public double ad() {
        return 11.09;
    }
}
